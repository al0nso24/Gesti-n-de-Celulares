/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Alonso
 */
    public class Celular {
        private int codigo;
        private String marca;
        private double precio;
        private int cantidad;

        public Celular(int codigo, String marca, double precio, int cantidad) {
            this.codigo = codigo;
            this.marca = marca;
            this.precio = precio;
            this.cantidad = cantidad;
        }

        public int getCodigo() {
            return codigo;
        }

        public void setCodigo(int codigo) {
            this.codigo = codigo;
        }

        public String getMarca() {
            return marca;
        }

        public void setMarca(String marca) {
            this.marca = marca;
        }

        public double getPrecio() {
            return precio;
        }

        public void setPrecio(double precio) {
            this.precio = precio;
        }

        public int getCantidad() {
            return cantidad;
        }

        public void setCantidad(int cantidad) {
            this.cantidad = cantidad;
        }

        @Override
        public String toString() {
            return " Codigo : " + codigo +"\n" + 
                   " Marca : " + marca + "\n" +
                   " Precio : " + precio + "\n" + 
                   " Cantidad : " + cantidad + "\n" + 
                   "-------------------------------\n";
        }
    }
