/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control.Pilas;

import Modelo.Celular;

/**
 *
 * @author Alonso
 */
public class Nodo_Pilas {
    private Celular dato;
    private Nodo_Pilas der;

    public Nodo_Pilas(Celular dato) {
        this.dato = dato;
        this.der = der;
    }
    

    public Celular getDato() {
        return dato;
    }

    public void setDato(Celular dato) {
        this.dato = dato;
    }

    public Nodo_Pilas getDer() {
        return der;
    }

    public void setDer(Nodo_Pilas der) {
        this.der = der;
    }
    
}
