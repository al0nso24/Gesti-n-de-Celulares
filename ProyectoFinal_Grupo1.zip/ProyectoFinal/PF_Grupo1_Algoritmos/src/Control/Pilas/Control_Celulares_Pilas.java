/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control.Pilas;

import Control.Pilas.Nodo_Pilas;
import Modelo.Celular;
import javax.swing.JOptionPane;

/**
 *
 * @author Alonso
 */
public class Control_Celulares_Pilas {
    private Nodo_Pilas tope, nuevo, p;
    
    public void apilar_Celular(Celular celular){
        nuevo = new Nodo_Pilas(celular);
        if(tope == null){
            tope=nuevo;
        }else{
            nuevo.setDer(tope);
            tope=nuevo;
        }
    }
    
    public Celular desapilar_Celular(){
        Celular valor = null;
        if(tope == null){
            JOptionPane.showMessageDialog(null, "La lista está vacía");
        }else{
            valor=tope.getDato();
            tope=tope.getDer();
        }
        return valor;
    }
    
    public String mostrar(){
        StringBuilder sb = new StringBuilder();
        p = tope;
        if(tope!=null){
            p=tope;
            while (p!=null) {                
                sb.append(p.getDato().toString());
                p = p.getDer();
            }
        }
        return  sb.toString();
    }
    
    public double calculaTotalVentas() {
        double total = 0;
        p = tope;
        while (p != null) {
            Celular c = p.getDato();
            total += c.getCantidad() * c.getPrecio();
            p = p.getDer();
        }
        return total;
    }
}
