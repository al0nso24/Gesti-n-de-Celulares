/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control.Colas_Circulares;

import Modelo.Celular;
import javax.swing.JOptionPane;



/**
 *
 * @author josue
 */
public class Control_Celulares_ColaCircular {
    private Celular[] cola;
    private int first, last;
    private int max;
    
    public Control_Celulares_ColaCircular(int capacidad){
        max = capacidad;
        cola = new Celular[max];
        first = -1;
        last = -1;
    
    }
    public boolean estaVacia(){
        return first == -1;
    }
    
    public boolean estaLlena(){
        return (last + 1) % max == first;
    }
    

    public void encolar(Celular c) {
        if (estaLlena()) {
          JOptionPane.showMessageDialog(null, "La cola está llena. No se puede registrar el celular.");
          return;
        }

        if (estaVacia()) {
            first = last = 0;
        }else{
            last = (last + 1) % max;
        }

        cola[last] = c;
        JOptionPane.showMessageDialog(null, "Celular registrado correctamente");
    }

    
    public Celular buscarPorCodigo(int codigo){
        if (estaVacia()){
            return null;
        }
        int i = first;
        boolean encontrado = false;
         while (i != (last + 1) % max && !encontrado) {
            if (cola[i].getCodigo() == codigo) {
                return cola[i];
            }
            i = (i + 1) % max;
        }
        return null;
    }
   

    public Celular desencolar() {
        if (estaVacia()) {
            JOptionPane.showMessageDialog(null, "No hay celulares, no se puede vender.");
            return null;
        }
        Celular eliminado = cola[first];
        if (first == last) {
            first = last = -1; // Solo había un elemento
        }else{
            first = (first + 1) % max;
        }
        JOptionPane.showMessageDialog(null, "Celular Vendido");
        return eliminado;
    }
    public String mostrarVentas() {
        if (estaVacia()) {
            return "Cola vacía.\n";
        }
        String resultado = "";
        int i = first;
        while (i != (last + 1) % max) {
            resultado += cola[i].toString() + "\n";
            i = (i + 1) % max;
        }
        return resultado;
    }

    
    public double calcularTotalVentas() {
        if (estaVacia()){
           return 0;
        }
        double total = 0;
        int i = first;
        while (i != (last + 1) % max) {
            Celular c = cola[i];
            total += c.getPrecio() * c.getCantidad();
            i = (i + 1) % max;
        }
        return total;
    }
}
