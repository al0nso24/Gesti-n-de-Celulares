/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control.LE;

import Modelo.Celular;

/**
 *
 * @author josue
 */
public class cNodo {
    
    private Celular dato;
    private cNodo sgte;

    public Celular getDato() {
        return dato;
    }
    public void setDato(Celular dato) {
        this.dato = dato;
    }
    public cNodo getSgte() {
        return sgte;
    }
    public void setSgte(cNodo sgte) {
        this.sgte = sgte;
    }  
}

