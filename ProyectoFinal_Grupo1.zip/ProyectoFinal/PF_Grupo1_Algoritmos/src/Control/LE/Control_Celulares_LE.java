/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control.LE;

import Control.LE.cNodo;
import Modelo.Celular;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
/**
 *
 * @author Alonso
 */
public class Control_Celulares_LE {
   private cNodo inicio, nuevo, p,q;
   
   
   //Metodo para insertar al final
    public void insertaCelularFinal(Celular celular){
        nuevo = new cNodo();
        nuevo.setDato(celular);
        if(inicio == null)
            inicio = nuevo;
        else{
            p = inicio;
            while(p.getSgte()!= null){
                p = p.getSgte();
            }
            p.setSgte(nuevo);
        }  
    }
    
    //Mostrar 
    public String mostrar(){
        StringBuilder sb = new StringBuilder();
        p = inicio;
        while(p !=null){
            sb.append(p.getDato().toString());
            p = p.getSgte();
        }
        return  sb.toString();
   }
   
    public void eliminarPorCodigo(int codigo) {
        if (inicio == null) {
           JOptionPane.showMessageDialog(null, "La lista está vacía.\n");
           return;
        }

    // Caso: primer nodo
        if (inicio.getDato().getCodigo() == codigo) {
           inicio = inicio.getSgte();
           JOptionPane.showMessageDialog(null, "Celular con código " + codigo + " eliminado.\n");
           return;
        }

    // Buscar en el resto de la lista
        p = inicio;
        while (p.getSgte() != null) {
            if (p.getSgte().getDato().getCodigo() == codigo) {
               p.setSgte(p.getSgte().getSgte());
               JOptionPane.showMessageDialog(null, "Celular con código " + codigo + " eliminado.\n");
               return;
            }
            p = p.getSgte();
        }
        JOptionPane.showMessageDialog(null, "No se encontró el celular con código " + codigo + ".\n");
}

    public double calculaTotalVentas() {
        double total = 0.0;
        p = inicio;

        while (p != null) {
            Celular c = p.getDato();
            total += c.getCantidad() * c.getPrecio(); // cantidad vendida × precio
            p = p.getSgte();
        }
        return total;
    }
    
    public boolean modificarCantidadPorCodigo(int codigo, int nuevaCantidad) {
        p = inicio;
        while (p != null) {
            if (p.getDato().getCodigo() == codigo) {
                p.getDato().setCantidad(nuevaCantidad);
                return true; // éxito
            }
            p = p.getSgte();
        }
        return false; // no encontrado
    }
}
