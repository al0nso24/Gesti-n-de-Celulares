/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control.Arreglo;

import Modelo.Celular;

/**
 *
 * @author Alonso
 */
public class Control_Celulares_Arreglos {
    //Arreglo:
    private static Celular[] listaCelulares = new Celular[20];
    private static int indUlt = -1;

    // Este metodo inserta un celular en el arreglo
    public static void insertarCelular(int indice, Celular nuevoCelular) {
        int indMayor = listaCelulares.length - 1;

        if (indice <= indUlt + 1 && indUlt < indMayor) {
            for (int i = indUlt; i >= indice; i--) {
                listaCelulares[i + 1] = listaCelulares[i];
            }
            listaCelulares[indice] = nuevoCelular;
            indUlt++;
        }
    }
    
    //Esta función muestra los celulares insertados.
    public static String mostrarArreglo() {
        StringBuilder sb = new StringBuilder();
        Celular[] lista = getListaCelulares();
        int total = getIndUlt();

        for (int i = 0; i <= total; i++) {
            Celular c = lista[i];
            if (c != null) {
                sb.append(c.toString());
            }
        }
        return sb.toString();
    }
    
    public static int getIndUlt() {
        return indUlt;
    }
    
    public static void eliminarCelular(int indice) {
        if(indice <=indUlt && indUlt >=0){
            for (int i = indice; i <indUlt; i++) {
                listaCelulares[i]= listaCelulares[i+1];
            }
            listaCelulares[indUlt]=null;
            indUlt--;
        }
    }

    public static Celular[] getListaCelulares() {
        return listaCelulares;
    }
    
    public static boolean modificarxCodigo(int codigo, String marca, int cantidad, double precio) {
        for (int i = 0; i <= indUlt; i++) {
            if (listaCelulares[i].getCodigo() == codigo) {
                listaCelulares[i].setMarca(marca);
                listaCelulares[i].setCantidad(cantidad);
                listaCelulares[i].setPrecio(precio);
                return true;
            }
        }
        return false;
    }
    
    public static double calcularTotalVentas() {
        double total = 0;
        for (int i = 0; i <= indUlt; i++) {
           Celular cel = listaCelulares[i];
           total += cel.getPrecio() * cel.getCantidad();
        }
        return total;
    }
}
