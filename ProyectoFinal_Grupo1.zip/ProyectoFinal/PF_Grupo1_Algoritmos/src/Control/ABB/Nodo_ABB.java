/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control.ABB;

import Modelo.Celular;


/**
 *
 * @author Alonso
 */
public class Nodo_ABB {
    private Celular valor;
    private Nodo_ABB izq, der;

    public Nodo_ABB(Celular valor) {
        this.valor = valor;
    }

    public Celular getValor() {
        return valor;
    }

    public void setValor(Celular valor) {
        this.valor = valor;
    }

    public Nodo_ABB getIzq() {
        return izq;
    }

    public void setIzq(Nodo_ABB izq) {
        this.izq = izq;
    }

    public Nodo_ABB getDer() {
        return der;
    }

    public void setDer(Nodo_ABB der) {
        this.der = der;
    }
    
}
