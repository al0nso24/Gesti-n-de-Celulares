/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control.ABB;

import Modelo.Celular;

/**
 *
 * @author Alonso
 */
public class Control_Celulares_ABB {
    private Nodo_ABB raiz, nuevo, p;
    
    public void insertarCelular(Celular celular) {
        nuevo = new Nodo_ABB(celular);
        if (raiz == null) {
            raiz = nuevo;
        } else {
            p=raiz;
            insertar_Nodo(raiz, nuevo);
        }
    }

    private void insertar_Nodo(Nodo_ABB p, Nodo_ABB nuevo){
        if(nuevo.getValor().getCodigo() < p.getValor().getCodigo()){
            if(p.getIzq() == null){
                p.setIzq(nuevo);
            }else{
                insertar_Nodo(p.getIzq(), nuevo);
            }
        }else{
            if(p.getDer() == null){
                p.setDer(nuevo);
            }else{
                insertar_Nodo(p.getDer(), nuevo);
            }
        }
    }

    public String mostrarInOrden() {
        return inOrden(raiz);
    }

    private String inOrden(Nodo_ABB p) {
        String resultado = "";
        if (p!=null){
            resultado += inOrden(p.getIzq());
            resultado += p.getValor().toString();
            resultado += inOrden(p.getDer());
        }
        return resultado;
    }
}
